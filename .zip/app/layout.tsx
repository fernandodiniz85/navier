import type { Metadata } from "next";
import { Playfair_Display, Inter } from "next/font/google";
import "./globals.css";
import { GoogleAnalytics } from '@next/third-parties/google';
import { ThemeProvider } from "./ThemeProvider"; // Importação do provedor de tema

// Configurar a fonte dos Títulos (Elegância)
const playfair = Playfair_Display({
  variable: "--font-serif",
  subsets: ["latin"],
});

// Configurar a fonte do Texto (Fluidez e Leitura)
const inter = Inter({
  variable: "--font-sans",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "NAVIER | Equipamentos Nature-Tech para Baristas",
  description: "Eleve o seu ritual do café. Equipamentos premium, precisão técnica e curadoria rigorosa para entusiastas e baristas.",
  openGraph: {
    title: "NAVIER | Equipamentos Premium",
    description: "Precisão técnica e formas orgânicas. Extraia o melhor de cada grão.",
    url: "https://www.navierpremium.com.br",
    siteName: "NAVIER",
    images: [
      {
        url: "https://www.navierpremium.com.br/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Logótipo NAVIER",
      },
    ],
    locale: "pt_BR",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    // O suppressHydrationWarning evita avisos no terminal por causa da troca de temas
    <html lang="pt-BR" suppressHydrationWarning className={`scroll-smooth ${inter.variable} ${playfair.variable} h-full antialiased`}>
      {/* Cores globais aplicadas com dark: para cobrir as margens do site */}
      <body className={`${inter.className} min-h-full flex flex-col font-sans bg-[#FFFFFF] dark:bg-[#1F5455] text-gray-900 dark:text-[#EABEA9] transition-colors duration-300`}>
        
        <ThemeProvider>
          {children}
        </ThemeProvider>
        
        {/* Radar do Google Analytics */}
        <GoogleAnalytics gaId="G-160ZGS3E85" />
        
      </body>
    </html>
  );
}