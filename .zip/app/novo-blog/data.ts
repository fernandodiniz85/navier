export const posts = [
  {
    id: "1",
    slug: "cafe-em-graos-ou-moido", 
    title: "Café em Grãos ou Moído: Por Que Moer na Hora Faz Diferença?",
    excerpt: "Descubra por que moer café na hora preserva melhor os aromas, como o frescor influencia a extração e como preparar um café melhor em casa ou durante viagens.",
    date: "03 Nov 2026",
    content: "" 
  },
  {
    id: "2",
    slug: "notas-sensoriais-do-cafe", 
    title: "Notas Sensoriais do Café: Como Identificar Sabores e Aromas",
    excerpt: "Entenda as notas sensoriais do café especial, descubra a diferença entre sabores achocolatados e frutados e aprenda a treinar seu paladar.",
    date: "03 Nov 2026",
    content: "" 
  }
];