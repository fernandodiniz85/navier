"use client";

import Link from 'next/link';
import { useTheme } from 'next-themes';
import { useEffect, useState } from 'react';

export default function Header() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  // Aguarda a montagem para evitar piscar cores incorretas
  useEffect(() => setMounted(true), []);

  return (
    // Note a adição do dark:bg-[#1F5455] para mudar o fundo no modo escuro
    <header className="w-full bg-[#FFFFFF] dark:bg-[#1F5455] py-4 px-8 flex items-center justify-between shadow-sm fixed top-0 z-50 transition-colors duration-300">
      
      <div className="flex items-center">
        <Link href="/">
          {/* Pode até usar um SVG diferente para o logótipo no futuro, usando as classes dark: */}
          <img 
            src="/logo.svg" 
            alt="Logotipo NAVIER" 
            className="h-14 object-contain cursor-pointer" 
          />
        </Link>
      </div>

      {/* Navegação - Textos ficam cor de cobre no modo escuro (dark:text-[#EABEA9]) */}
      <nav className="hidden md:flex gap-8 text-sm font-medium text-[#1F5455] dark:text-[#EABEA9] tracking-wider uppercase items-center transition-colors duration-300">
        <a href="#ritual" className="hover:text-[#EABEA9] dark:hover:text-white transition-colors">O Ritual</a>
        <a href="#produtos" className="hover:text-[#EABEA9] dark:hover:text-white transition-colors">Equipamentos</a>
        <a href="#faq" className="hover:text-[#EABEA9] dark:hover:text-white transition-colors">FAQ</a>
        
        <Link href="/novo-blog" className="hover:text-[#EABEA9] dark:hover:text-white transition-colors font-bold border-l border-[#1F5455]/20 dark:border-[#EABEA9]/20 pl-8">
          Journal
        </Link>
      </nav>

      <div className="flex items-center gap-6">
        {/* O nosso novo botão de Tema */}
        {mounted && (
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="text-[#1F5455] dark:text-[#EABEA9] hover:text-[#8FA98C] transition-colors"
            aria-label="Alternar Tema"
          >
            {theme === 'dark' ? (
              // Ícone de Sol
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
            ) : (
              // Ícone de Lua
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
            )}
          </button>
        )}

        <button className="bg-[#1F5455] dark:bg-[#EABEA9] text-white dark:text-[#1F5455] px-6 py-2 rounded text-sm uppercase tracking-wider hover:bg-[#8FA98C] dark:hover:bg-white transition-colors">
          Ver Produtos
        </button>
      </div>

    </header>
  );
}