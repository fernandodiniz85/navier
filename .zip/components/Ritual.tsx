export default function Ritual() {
  return (
    // Adicionado dark:bg-[#1F5455] para mudar o fundo no modo escuro
    <section id="ritual" className="w-full bg-[#FFFFFF] dark:bg-[#1F5455] py-24 px-6 transition-colors duration-300">
      <div className="max-w-4xl mx-auto text-center">
        {/* Adicionado dark:text-[#EABEA9] para o título */}
        <h2 className="text-3xl font-serif text-[#1F5455] dark:text-[#EABEA9] tracking-widest mb-4 transition-colors duration-300">
          A PAUSA, O GRÃO E O RITUAL
        </h2>
        <div className="w-16 h-1 bg-[#EABEA9] mx-auto mb-12"></div>
        
        {/* Adicionado dark:text-gray-300 para melhorar a leitura do texto principal */}
        <p className="text-gray-600 dark:text-gray-300 mb-8 leading-relaxed text-lg text-justify px-4 transition-colors duration-300">
          Num mundo que corre contra o relógio, o momento de preparar um café é o seu porto seguro. É a pausa necessária para se desconectar do caos e recarregar a energia. Na NAVIER, acreditamos que essa experiência é um ritual terapêutico que começa muito antes de a água tocar no pó.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          <div className="border-t border-[#8FA98C] pt-6">
            {/* Adicionado dark:text-[#EABEA9] para o subtítulo */}
            <h3 className="text-[#1F5455] dark:text-[#EABEA9] font-serif text-xl mb-3 text-center md:text-left transition-colors duration-300">
              A Origem e Cultivo
            </h3>
            {/* Adicionado dark:text-gray-400 para o texto descritivo */}
            <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed text-justify transition-colors duration-300">
              Tudo começa nas montanhas. A colheita manual e seletiva garante que apenas os frutos no pico da maturação cheguem à sua xícara, preservando a doçura natural, os óleos essenciais e a complexidade do terroir.
            </p>
          </div>
          <div className="border-t border-[#8FA98C] pt-6">
            <h3 className="text-[#1F5455] dark:text-[#EABEA9] font-serif text-xl mb-3 text-center md:text-left transition-colors duration-300">
              A Arte da Torra
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed text-justify transition-colors duration-300">
              A torra é a alquimia do grão. Torras claras destacam a acidez e notas frutadas; as médias trazem o equilíbrio do caramelo e chocolate; enquanto as mais escuras encorpam a bebida. O grão dita o caminho.
            </p>
          </div>
          <div className="border-t border-[#8FA98C] pt-6">
            <h3 className="text-[#1F5455] dark:text-[#EABEA9] font-serif text-xl mb-3 text-center md:text-left transition-colors duration-300">
              A Extração Exata
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed text-justify transition-colors duration-300">
              A magia final está nas suas mãos. A combinação do método correto, a precisão da moagem e a qualidade da filtração revelam o potencial máximo que a natureza guardou durante meses.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}