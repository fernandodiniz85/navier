export default function Faq() {
  return (
    <section id="faq" className="w-full bg-[#F9F9F9] dark:bg-[#1A4748] py-24 px-6 transition-colors duration-300">
      <div className="max-w-4xl mx-auto">
        
        <div className="text-center mb-16">
          <h2 className="text-3xl font-serif text-[#1F5455] dark:text-[#EABEA9] tracking-widest mb-4 transition-colors duration-300">PERGUNTAS FREQUENTES</h2>
          <div className="w-16 h-1 bg-[#EABEA9] mx-auto"></div>
        </div>
        
        <div className="space-y-6">
          <div className="bg-white dark:bg-[#1F5455] p-6 border border-gray-100 dark:border-[#EABEA9]/20 shadow-sm transition-colors duration-300">
            <h3 className="text-[#1F5455] dark:text-[#EABEA9] font-medium tracking-wider mb-2 transition-colors duration-300">Os equipamentos têm garantia?</h3>
            <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed transition-colors duration-300">Sim. Todos os produtos NAVIER possuem garantia contra defeitos de fabrico. A compra através do Mercado Livre também assegura a devolução gratuita caso o produto não corresponda às suas expectativas.</p>
          </div>
          
          <div className="bg-white dark:bg-[#1F5455] p-6 border border-gray-100 dark:border-[#EABEA9]/20 shadow-sm transition-colors duration-300">
            <h3 className="text-[#1F5455] dark:text-[#EABEA9] font-medium tracking-wider mb-2 transition-colors duration-300">Qual o prazo de entrega?</h3>
            <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed transition-colors duration-300">O envio é processado através da logística rápida do Mercado Livre, o que significa que receberá a sua encomenda no menor tempo possível, muitas vezes no dia seguinte, dependendo da sua região.</p>
          </div>

          <div className="bg-white dark:bg-[#1F5455] p-6 border border-gray-100 dark:border-[#EABEA9]/20 shadow-sm transition-colors duration-300">
            <h3 className="text-[#1F5455] dark:text-[#EABEA9] font-medium tracking-wider mb-2 transition-colors duration-300">O Filtro V60 serve noutros suportes?</h3>
            <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed transition-colors duration-300">Os nossos filtros foram desenhados com a angulação e textura perfeitas para o método V60, garantindo a fluidez ideal da água. Podem ser usados em qualquer suporte cónico de tamanho compatível.</p>
          </div>
        </div>

      </div>
    </section>
  );
}